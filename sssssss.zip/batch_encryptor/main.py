import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import random
import string
import os
from datetime import datetime
import re

# --- CORE ENCRYPTION LOGIC ---

def generate_key(index, length, mode, is_random_length):
    if is_random_length:
        length = random.randint(2, max(2, length))
    
    if mode == "Sequential Numbers":
        return "v" + str(index).zfill(length - 1)
    
    if mode == "Random Numbers":
        return random.choice(string.ascii_letters) + "".join(random.choice(string.digits) for _ in range(length - 1))
    
    if mode == "Random Letters":
        return "".join(random.choice(string.ascii_letters) for _ in range(length))
    
    # Random Letters + Numbers
    first_char = random.choice(string.ascii_letters)
    rest = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(length - 1))
    return first_char + rest

def perform_encryption(content, max_length, mode, is_random_length, remove_comments, obfuscate_labels, obfuscate_vars, keep_percent=True, keep_spaces=True, safety_cap=True):
    lines = content.splitlines(keepends=False)
    
    system_vars = {"PATH", "TEMP", "TMP", "CD", "DATE", "TIME", "RANDOM", "ERRORLEVEL", "USERNAME", "USERPROFILE", "PROGRAMFILES", "WINDIR", "APPDATA"}
    protected_cmds = {"whoami", "net", "user", "dir", "find", "findstr", "tasklist", "taskkill", "attrib", "copy", "move", "del", "mkdir", "rmdir"}

    # 1. Label Obfuscation
    if obfuscate_labels:
        found_labels = {m.group(1) for line in lines if (m := re.match(r'^\s*:([a-zA-Z0-9_-]+)', line)) and m.group(1).upper() != "EOF"}
        label_map = {lbl: "L_" + "".join(random.choices(string.ascii_letters + string.digits, k=8)) for lbl in found_labels}
        new_lines = []
        for line in lines:
            def_match = re.match(r'^(\s*):([a-zA-Z0-9_-]+)(.*)', line)
            if def_match:
                p, lbl, s = def_match.groups()
                if lbl in label_map: line = f"{p}:{label_map[lbl]}{s}"
            line = re.sub(r'\b(goto|call)\s+([a-zA-Z0-9_-]+)', lambda m: f"{m.group(1)} {label_map.get(m.group(2), m.group(2))}", line, flags=re.I)
            line = re.sub(r'\b(call)\s+:([a-zA-Z0-9_-]+)', lambda m: f"{m.group(1)} :{label_map.get(m.group(2), m.group(2))}", line, flags=re.I)
            new_lines.append(line)
        lines = new_lines

    # 2. Variable Obfuscation
    if obfuscate_vars:
        found_vars = set()
        for line in lines:
            m = re.search(r'\bset\s+(?:/[pa]\s+)?(?:")?([a-zA-Z0-9_]+)', line, re.I)
            if m:
                v = m.group(1)
                if v.upper() not in system_vars and not v.isdigit(): found_vars.add(v)
        var_map = {v: "V_" + "".join(random.choices(string.ascii_letters + string.digits, k=8)) for v in found_vars}
        new_lines = []
        for line in lines:
            line = re.sub(r'\bset\s+(?:/[pa]\s+)?(?:")?([a-zA-Z0-9_]+)', lambda m: m.group(0).replace(m.group(1), var_map.get(m.group(1), m.group(1))), line, flags=re.I)
            line = re.sub(r'%([a-zA-Z0-9_]+)%', lambda m: f"%{var_map.get(m.group(1), m.group(1))}%", line)
            line = re.sub(r'!([a-zA-Z0-9_]+)!', lambda m: f"!{var_map.get(m.group(1), m.group(1))}!", line)
            new_lines.append(line)
        lines = new_lines

    # 3. Character Mapping
    processed_lines = []
    for line in lines:
        if remove_comments:
            if line.strip().lower().startswith("rem ") or line.strip().lower() == "rem" or line.strip().startswith("::"): continue
        processed_lines.append(line + "\n")
    
    clean_content = "".join(processed_lines)
    safe_symbols = ['(', ')', "'", '!', '[', ']', ',', ';', '=', '`', ':', '/', '\\', '.', '?', '*', '-', '+', '<', '>', '|', '&']
    
    chars_to_map = clean_content.replace("\r", "").replace("\n", "")
    if keep_percent: chars_to_map = chars_to_map.replace("%", "")
    if keep_spaces: chars_to_map = chars_to_map.replace(" ", "")
    for s in safe_symbols: chars_to_map = chars_to_map.replace(s, "")
    unique_chars = sorted(list(set(chars_to_map)))
    
    mapping = {}
    used_keys = set()
    header = ["@echo off", "chcp 65001 >nul"]
    
    for i, char in enumerate(unique_chars):
        this_max = max_length
        if safety_cap and this_max > 25: this_max = 25
        while True:
            key = generate_key(i, this_max, mode, is_random_length)
            if key not in used_keys:
                used_keys.add(key)
                break
        mapping[char] = key
        if char == '"': header.append(f'set {key}="')
        elif char == '%': header.append(f'set "{key}=%%"')
        elif char == '^': header.append(f'set "{key}=^^"')
        else: header.append(f'set "{key}={char}"')

    # 4. Final Encryption
    encrypted_lines = []
    max_line_len = 0
    protected_regex = r'(%%[a-zA-Z0-9]|%[a-zA-Z0-9_]+%|![a-zA-Z0-9_]+!|%\~[a-zA-Z0-9]+|%\d|^\s*:[a-zA-Z0-9_-]+|\b(?:goto|call)\s+[a-zA-Z0-9_-]+|\bset\s+(?:/[pa]\s+)?(?:")?[a-zA-Z0-9_]+|\b(?:' + "|".join(protected_cmds) + r')\b)'
    
    for line in processed_lines:
        parts = re.split(protected_regex, line, flags=re.M | re.I)
        new_line = ""
        for part in parts:
            if part is None: continue
            if re.match(protected_regex, part, flags=re.M | re.I):
                new_line += part
            else:
                for char in part:
                    if char in mapping and char not in safe_symbols:
                        key = mapping[char]
                        if safety_cap and len(new_line) > 7500:
                            new_line += char 
                        else:
                            new_line += f"%{key}%"
                    else:
                        new_line += char 
        encrypted_lines.append(new_line)
        max_line_len = max(max_line_len, len(new_line))
        
    final = "\n".join(header) + "\n\n" + "".join(encrypted_lines)
    return final, max_line_len

# --- GUI ---

class BatchApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Batch Encryptor IDE - Longer Pass v6")
        self.root.geometry("1100x850")
        self.setup_menu()
        self.notebook = ttk.Notebook(root); self.notebook.pack(expand=True, fill="both")
        self.setup_encryptor_tab(); self.setup_ide_tab()
        
    def setup_menu(self):
        m = tk.Menu(self.root); self.root.config(menu=m)
        f = tk.Menu(m, tearoff=0); m.add_cascade(label="File", menu=f)
        f.add_command(label="Save Source", command=self.save_source_as)
        f.add_command(label="Save Encrypted", command=self.save_encrypted_as)

    def setup_encryptor_tab(self):
        t = ttk.Frame(self.notebook); self.notebook.add(t, text="File Encryptor")
        f = ttk.LabelFrame(t, text="Files"); f.pack(fill="x", padx=20, pady=10)
        self.entry_input = ttk.Entry(f, width=60); self.entry_input.grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(f, text="Browse", command=self.browse_input).grid(row=0, column=2, padx=5, pady=5)
        self.entry_output = ttk.Entry(f, width=60); self.entry_output.grid(row=1, column=1, padx=5, pady=5)
        ttk.Button(f, text="Save As", command=self.browse_output).grid(row=1, column=2, padx=5, pady=5)
        
        o = ttk.LabelFrame(t, text="Options"); o.pack(fill="x", padx=20, pady=5)
        self.var_len = tk.IntVar(value=12); tk.Scale(o, from_=1, to=500, orient="horizontal", label="Var Length", variable=self.var_len).pack(fill="x", padx=10)
        self.combo_style = ttk.Combobox(o, values=["Random Letters + Numbers", "Random Letters", "Random Numbers", "Sequential Numbers"], state="readonly")
        self.combo_style.set("Random Letters + Numbers"); self.combo_style.pack(pady=5)
        
        self.var_longer_enc = tk.BooleanVar(value=False); ttk.Checkbutton(o, text="Longer Encryption (Runs 100x and picks best result)", variable=self.var_longer_enc).pack(anchor="w", padx=20)
        self.var_use_bom = tk.BooleanVar(value=False);
        self.var_safety_cap = tk.BooleanVar(value=True); ttk.Checkbutton(o, text="Smart Safety Cap", variable=self.var_safety_cap).pack(anchor="w", padx=20)
        self.var_obf_labels = tk.BooleanVar(value=True); ttk.Checkbutton(o, text="Scramble Labels", variable=self.var_obf_labels).pack(anchor="w", padx=20)
        self.var_obf_vars = tk.BooleanVar(value=True); ttk.Checkbutton(o, text="Scramble Variables", variable=self.var_obf_vars).pack(anchor="w", padx=20)
        ttk.Button(t, text="ENCRYPT FILE", command=self.run_file_encryption).pack(pady=10)

    def setup_ide_tab(self):
        t = ttk.Frame(self.notebook); self.notebook.add(t, text="Live IDE")
        p = ttk.PanedWindow(t, orient="horizontal"); p.pack(expand=True, fill="both")
        self.text_editor = tk.Text(p, undo=True, wrap="none", font=("Consolas", 11)); p.add(self.text_editor, weight=1)
        self.text_editor.bind("<KeyRelease>", self.on_ide_change)
        self.text_preview = tk.Text(p, wrap="char", font=("Consolas", 9), bg="#f8f8f8"); p.add(self.text_preview, weight=1)
        self.status = ttk.Label(t, text="Ready", relief="sunken", anchor="w"); self.status.pack(side="bottom", fill="x")

    def get_best_encryption(self, src):
        best_enc = ""
        best_len = 0
        best_mlen = 0
        iterations = 100 if self.var_longer_enc.get() else 1
        
        for _ in range(iterations):
            enc, mlen = perform_encryption(src, self.var_len.get(), self.combo_style.get(), True, True, self.var_obf_labels.get(), self.var_obf_vars.get(), True, True, self.var_safety_cap.get())
            if len(enc) > best_len:
                best_len = len(enc)
                best_enc = enc
                best_mlen = mlen
        return best_enc, best_mlen

    def on_ide_change(self, event=None):
        src = self.text_editor.get("1.0", tk.END).strip()
        if src:
            enc, mlen = self.get_best_encryption(src)
            self.text_preview.config(state="normal"); self.text_preview.delete("1.0", tk.END); self.text_preview.insert("1.0", enc); self.text_preview.config(state="disabled")
            self.status.config(text=f"Max Line: {mlen} chars. Passes: {'100' if self.var_longer_enc.get() else '1'}", foreground="black")
            self.auto_save_ide(src)

    def auto_save_ide(self, content):
        now = datetime.now(); dp = os.path.join("editor", f"temp_{now.strftime('%d%m%Y')}")
        enc = "utf-8-sig" if self.var_use_bom.get() else "utf-8"
        try:
            if not os.path.exists(dp): os.makedirs(dp)
            with open(os.path.join(dp, f"editor_{now.strftime('%H.%M')}.bat"), "w", encoding=enc) as f: f.write(content)
        except: pass

    def save_source_as(self):
        p = filedialog.asksaveasfilename(defaultextension=".bat")
        enc = "utf-8-sig" if self.var_use_bom.get() else "utf-8"
        if p:
            with open(p, "w", encoding=enc) as f: f.write(self.text_editor.get("1.0", tk.END))
    def save_encrypted_as(self):
        p = filedialog.asksaveasfilename(defaultextension=".bat")
        enc = "utf-8-sig" if self.var_use_bom.get() else "utf-8"
        if p:
            with open(p, "w", encoding=enc) as f: f.write(self.text_preview.get("1.0", tk.END))
    def browse_input(self):
        p = filedialog.askopenfilename()
        if p: self.entry_input.delete(0, tk.END); self.entry_input.insert(0, p)
    def browse_output(self):
        p = filedialog.asksaveasfilename(defaultextension=".bat")
        if p: self.entry_output.delete(0, tk.END); self.entry_output.insert(0, p)
    def run_file_encryption(self):
        inp, out = self.entry_input.get(), self.entry_output.get()
        if not inp or not out: return
        enc = "utf-8-sig" if self.var_use_bom.get() else "utf-8"
        with open(inp, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
        enc_res, mlen = self.get_best_encryption(content)
        with open(out, "w", encoding=enc) as f: f.write(enc_res)
        messagebox.showinfo("Done", f"Success! Picked longest from {'100' if self.var_longer_enc.get() else '1'} iterations.")

if __name__ == "__main__":
    root = tk.Tk(); app = BatchApp(root); root.mainloop()
